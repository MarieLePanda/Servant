#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      lug13995
#
# Created:     23/05/2014
# Copyright:   (c) lug13995 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import random
import socket
from Card import Card
from Player import Player
from CardSet import CardSet
from FieldNetwork import FieldNetwork

def main():

#C:\Users\lug13995\Desktop\ESGI\Portable Python 3.2.5.1\Servant\Exo 2
    listCard = CardSet.loadCardSet("C:\\Users\\lug13995\\Desktop\\ESGI\\Portable Python 3.2.5.1\\Servant\\Exo 2\\CardSet")
    i = 0

    while(winner)
    playerOne = Player("panda", listCard)
    playerTwo = Player("koala", listCard)
    i = 0
    winner = None
    pass

if __name__ == '__main__':
    main()
